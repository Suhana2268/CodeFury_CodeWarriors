package com.webapp.models;

import java.sql.Date;
import java.sql.Time;

public class Booking {
	private int bookingId;
	private String password;
	private MeetingRoom room; //foreign key
	private Date meetingDate;
	private Time startTime;
	private Time endTime;
	private User bookedBy; //foreign key
	private String title;
	private String meetingType;
	private int cost;
	
	public Booking() {
		bookedBy=new User();
		room= new MeetingRoom();
	}

	
	
	public Booking(String password, MeetingRoom room, Date meetingDate, Time startTime, Time endTime, User bookedBy,
			String title, String meetingType, int cost) {
		super();
		this.password = password;
		this.room = room;
		this.meetingDate = meetingDate;
		this.startTime = startTime;
		this.endTime = endTime;
		this.bookedBy = bookedBy;
		this.title = title;
		this.meetingType = meetingType;
		this.cost = cost;
	}



	public Booking(String password, String meetingRoomName, Date meetingDate, Time startTime, Time endTime, int userId,
			String title, String meetingType, int cost) {
		super();
		this.password = password;
		this.room.setMeetingRoomName(meetingRoomName);
		this.meetingDate = meetingDate;
		this.startTime = startTime;
		this.endTime = endTime;
		this.bookedBy.setUserId(userId);
		this.title = title;
		this.meetingType = meetingType;
		this.cost = cost;
	}


	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public MeetingRoom getRoom() {
		return room;
	}

	public void setRoom(MeetingRoom room) {
		this.room = room;
	}

	public Date getMeetingDate() {
		return meetingDate;
	}

	public void setMeetingDate(Date meetingDate) {
		this.meetingDate = meetingDate;
	}

	public Time getStartTime() {
		return startTime;
	}

	public void setStartTime(Time startTime) {
		this.startTime = startTime;
	}

	public Time getEndTime() {
		return endTime;
	}

	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}

	public User getBookedBy() {
		return bookedBy;
	}

	public void setBookedBy(User bookedBy) {
		this.bookedBy = bookedBy;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMeetingType() {
		return meetingType;
	}

	public void setMeetingType(String meetingType) {
		this.meetingType = meetingType;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", password=" + password + ", room=" + room.toString() + ", meetingDate="
				+ meetingDate + ", startTime=" + startTime + ", endTime=" + endTime + ", bookedBy=" + bookedBy.toString()
				+ ", title=" + title + ", meetingType=" + meetingType + ", cost=" + cost + "]";
	}
	
	

}
