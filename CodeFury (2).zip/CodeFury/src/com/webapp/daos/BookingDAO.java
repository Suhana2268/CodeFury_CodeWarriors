package com.webapp.daos;

import java.util.List;

import com.webapp.models.Amenities;
import com.webapp.models.Booking;
import com.webapp.models.User;

public interface BookingDAO {
	
	boolean addBooking(Booking details);
	List<Amenities> getAmenities();
	Booking getBookingInfo(int bookingId);
	List<Booking> getAllBoookings();
	int getCostBooking(int bookingId);
	boolean addMemberToMeeting(int bookingId, List<User> users);
	List<User> getMembersofMeeting(int bookingId);
	int evaluateCost(String meetingRoomName, String meetingType);

}
